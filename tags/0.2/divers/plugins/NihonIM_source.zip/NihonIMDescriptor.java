/*
 * @(#)CityInputMethodDescriptor.java	1.2 99/12/03
 * 
 * Copyright 1999 by Sun Microsystems, Inc.,
 * 901 San Antonio Road, Palo Alto, California, 94303, U.S.A.
 * All rights reserved.
 */

package org.igoweb.nihonIM;

import java.awt.Image;
import java.awt.im.spi.InputMethod;
import java.awt.im.spi.InputMethodDescriptor;
import java.util.Locale;

/**
 * Provides sufficient information about an input method
 * to enable selection and loading of that input method.
 * The input method itself is only loaded when it is actually used.
 */

public class NihonIMDescriptor
  implements InputMethodDescriptor {
  
  public NihonIMDescriptor() {
  }
  
  /**
   * @see java.awt.im.spi.InputMethodDescriptor#getAvailableLocales
   */
  public Locale[] getAvailableLocales() {
    Locale[] locales = {Locale.JAPANESE};
    return locales;
  }
  
  /**
   * @see java.awt.im.spi.InputMethodDescriptor#hasDynamicLocaleList
   */
  public boolean hasDynamicLocaleList() {
    return false;
  }
  
  /**
   * @see java.awt.im.spi.InputMethodDescriptor#getInputMethodDisplayName
   */
  public synchronized String getInputMethodDisplayName(
    Locale inputLocale, Locale displayLanguage) {

    return "Nihon IM";
  }
  
  /**
   * @see java.awt.im.spi.InputMethodDescriptor#getInputMethodIcon
   */
  public Image getInputMethodIcon(Locale inputLocale) {
    return null;
  }
  
  /**
   * @see java.awt.im.spi.InputMethodDescriptor#createInputMethod
   */
  public InputMethod createInputMethod() throws Exception {
    return(new NihonIM());
  }
  
  public String toString() {
    Locale loc[] = getAvailableLocales();
    String locnames = null;
    
    for (int i = 0; i < loc.length; i++) {
      if (locnames == null) {
	locnames = loc[i].toString();
      } else {
	locnames += "," + loc[i];
      }
    }
    return getClass().getName() + "[" +
      "locales=" + locnames +
      ",localelist=" + (hasDynamicLocaleList() ? "dynamic" : "static") +
      "]";
  }
}
