/*
 * $Source: /cvs/java/org/igoweb/nihonIM/NihonIM.java,v $
 * $Revision: 1.12 $
 * $Date: 2003/01/16 19:01:20 $
 *
 * Copyright © 2003 William Shubert
 */

package org.igoweb.nihonIM;

import java.awt.AWTEvent;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.InputMethodEvent;
import java.awt.event.KeyEvent;
import java.awt.font.TextAttribute;
import java.awt.font.TextHitInfo;
import java.awt.im.InputMethodHighlight;
import java.awt.im.spi.InputMethod;
import java.awt.im.spi.InputMethodContext;
import java.io.IOException;
import java.text.AttributedString;
import java.util.HashMap;
import java.util.Locale;

public class NihonIM
  implements InputMethod {
  
  private static Locale[] SUPPORTED_LOCALES = {
    Locale.JAPANESE};

  private InputMethodContext inputMethodContext;
  private boolean active;
  private boolean disposed;
  private Locale locale;
  private boolean converted;
  private int cursor;
  private final StringBuffer rawText = new StringBuffer();
  private boolean isHiragana;
  private boolean consumeDel = false;

  private static final HashMap hiragana = new HashMap();
  private static final HashMap katakana = new HashMap();
  private static final int maxKeyLen;

  static {
    int hMaxLen = initHashMap(
      hiragana,
      "a|あ|i|い|u|う|e|え|o|お|" +
      "kya|きゃ|kyu|きゅ|kyo|きょ|" + "ka|か|ki|き|ku|く|ke|け|ko|こ|" +   
      "sha|しゃ|shu|しゅ|sho|しょ|" + "sa|さ|shi|し|su|す|se|せ|so|そ|" +  
      "cha|ちゃ|chu|ちゅ|cho|ちょ|" + "ta|た|chi|ち|tsu|つ|te|て|to|と|" + 
      "nya|にゃ|nyu|にゅ|nyo|にょ|" + "na|な|ni|に|nu|ぬ|ne|ね|no|の|" +   
      "hya|ひゃ|hyu|ひゅ|hyo|ひょ|" + "ha|は|hi|ひ|fu|ふ|he|へ|ho|ほ|" +   
      "mya|みゃ|myu|みゅ|myo|みょ|" + "ma|ま|mi|み|mu|む|me|め|mo|も|" +   
      "ya|や|yu|ゆ|yo|よ|" +
      "rya|りゃ|ryu|りゅ|ryo|りょ|" + "ra|ら|ri|り|ru|る|re|れ|ro|ろ|" +   
      "wa|わ|wo|を|" +
      "n|ん|" +
      "gya|ぎゃ|gyu|ぎゅ|gyo|ぎょ|" + "ga|が|gi|ぎ|gu|ぐ|ge|げ|go|ご|" +   
      "ja|じゃ|ju|じゅ|jo|じょ|" +    "za|ざ|ji|じ|zu|ず|ze|ぜ|zo|ぞ|" +   
      "da|だ|JI|ぢ|du|づ|de|で|do|ど|" +
      "bya|びゃ|byu|びゅ|byo|びょ|" + "ba|ば|bi|び|bu|ぶ|be|べ|bo|ぼ|" +   
      "pya|ぴゃ|pyu|ぴゅ|pyo|ぴょ|" + "pa|ぱ|pi|ぴ|pu|ぷ|pe|ぺ|po|ぽ|",
      'っ');
    int kMaxLen = initHashMap(
      katakana,
      "a|ア|i|イ|u|ウ|e|エ|o|オ|" +
      "kya|キャ|kyu|キュ|kyo|キョ|" + "ka|カ|ki|キ|ku|ク|ke|ケ|ko|コ|" +   
      "sha|シャ|shu|シュ|sho|ショ|" + "sa|サ|shi|シ|su|ス|se|セ|so|ソ|" +  
      "cha|チャ|chu|チュ|cho|チョ|" + "ta|タ|chi|チ|tsu|ツ|te|テ|to|ト|" + 
      "nya|ニャ|nyu|ニュ|nyo|ニョ|" + "na|ナ|ni|ニ|nu|ヌ|ne|ネ|no|ノ|" +   
      "hya|ヒャ|hyu|ヒュ|hyo|ヒョ|" + "ha|ハ|hi|ヒ|fu|フ|he|ヘ|ho|ホ|" +   
      "mya|ミャ|myu|ミュ|myo|ミョ|" + "ma|マ|mi|ミ|mu|ム|me|メ|mo|モ|" +   
      "ya|ヤ|yu|ユ|yo|ヨ|" +
      "rya|リャ|ryu|リュ|ryo|リョ|" + "ra|ラ|ri|リ|ru|ル|re|レ|ro|ロ|" +   
      "wa|ワ|wo|ヲ|" +
      "n|ン|" +
      "gya|ギャ|gyu|ギュ|gyo|ギョ|" + "ga|ガ|gi|ギ|gu|グ|ge|ゲ|go|ゴ|" +   
      "ja|ジャ|ju|ジュ|jo|ジョ|" +    "za|ザ|ji|ジ|zu|ズ|ze|ゼ|zo|ゾ|" +   
      "da|ダ|JI|ヂ|du|ヅ|de|デ|do|ド|" +
      "bya|ビャ|byu|ビュ|byo|ビョ|" + "ba|バ|bi|ビ|bu|ブ|be|ベ|bo|ボ|" +   
      "pya|ピョ|pyu|ピュ|pyo|ピョ|" + "pa|パ|pi|ピ|pu|プ|pe|ペ|po|ポ|" +   
      "-|ー|", 'ッ');
    maxKeyLen = (hMaxLen > kMaxLen ? hMaxLen : kMaxLen);
  }
  
  public NihonIM()
    throws IOException {

    cursor = 0;
    isHiragana = true;
  }
  
  public void setInputMethodContext(InputMethodContext context) {
    inputMethodContext = context;
  }
  
  public boolean setLocale(Locale locale) {
    this.locale = locale;
    return(true);
  }
  
  public Locale getLocale() {
    return locale;
  }
  
  public void setCharacterSubsets(Character.Subset[] subsets) {
    // ignore
  }
  
  public void reconvert() {
    // not supported yet
    throw new UnsupportedOperationException();
  }
  
  public void dispatchEvent(AWTEvent event) {
    switch(event.getID()) {
    case KeyEvent.KEY_PRESSED:
      handleKeyPressed((KeyEvent)event);
      break;
    case KeyEvent.KEY_TYPED:
      handleKeyTyped((KeyEvent)event);
      break;
    default:
      break;
    }
  }

  private void handleKeyPressed(KeyEvent e) {
    switch(e.getKeyCode()) {
    case KeyEvent.VK_LEFT:
      if (cursor > 0) {
	--cursor;
      } else {
	return;
      }
      break;
    case KeyEvent.VK_RIGHT:
      if (cursor < rawText.length()) {
	++cursor;
      } else {
	return;
      }
      break;
    case KeyEvent.VK_UP:
      if (rawText.length() == 0) {
	return;
      }
      isHiragana = true;
      break;
    case KeyEvent.VK_DOWN:
      if (rawText.length() == 0) {
	return;
      }
      isHiragana = false;
      break;
    case KeyEvent.VK_BACK_SPACE:
      if (rawText.length() == 0) {
	return;
      }
      if (cursor > 0) {
	rawText.deleteCharAt(--cursor);
      }
      consumeDel = true;
      break;
    case KeyEvent.VK_DELETE:
      if (rawText.length() == 0) {
	return;
      }
      if (cursor < rawText.length()) {
	rawText.deleteCharAt(cursor);
      }
      consumeDel = true;
      break;
    default:
      return;
    }
    e.consume();
    sendText(null);
  }

  private void handleKeyTyped(KeyEvent e) {
    char ch = e.getKeyChar();
    if (ch == ' ') {
      e.consume();
      if (cursor > 0) {
	commit();
      } else {
	rawText.insert(cursor++, ' ');
	sendText(null);
      }
    } else if (ch == '\n') {
      e.consume();
      commit();
    } else if ((('a' <= ch) && (ch <= 'z'))
	       || (('A' <= ch) && (ch <= 'Z')) || (ch == '-')) {
      e.consume();
      rawText.insert(cursor++, ch);
      sendText(null);
    } else if ((e.getKeyCode() == KeyEvent.VK_BACK_SPACE)
	       || (e.getKeyCode() == KeyEvent.VK_DELETE)) {
      if (consumeDel) {
	consumeDel = false;
	e.consume();
      }
    } else if (rawText.length() != 0) {
      e.consume();
      Toolkit.getDefaultToolkit().beep();
    }
  }
  
  public void activate() {
    active = true;
    rawText.setLength(0);
    cursor = 0;
    isHiragana = true;
    consumeDel = false;
  }
  
  public void deactivate(boolean isTemporary) {
    active = false;
  }
  
  public void hideWindows() {
  }
  
  public void removeNotify() {
  }
  
  public void endComposition() {
    if (rawText.length() != 0) {
      cursor = rawText.length();
      commit();
    }
    isHiragana = true;
  }
  
  public void notifyClientWindowChange(Rectangle location) {
  }
  
  public void dispose() {
    disposed = true;
  }
  
  public Object getControlObject() {
    return null;
  }
  
  public void setCompositionEnabled(boolean enable) {
    // not supported yet
    throw new UnsupportedOperationException();
  }
  
  public boolean isCompositionEnabled() {
    // always enabled
    return true;
  }
  
  private void initializeTables() throws IOException {
  }
  
  private void commit() {
    consumeDel = false;
    if (cursor > 0) {
      String committed;
      if (cursor == rawText.length()) {
	committed = convert(rawText.toString());
	rawText.setLength(0);
      } else {
	committed = convert(rawText.substring(0, cursor));
	rawText.replace(0, cursor, "");
      }
      cursor = 0;
      sendText(committed);
    }
  }

  private String convert(String in) {
    StringBuffer out = new StringBuffer(in);
    HashMap xlats = (isHiragana ? hiragana : katakana);
    for (int len = maxKeyLen; len >= 1; --len) {
      for (int i = 0; i <= out.length() - len; ++i) {
	String xlat = (String)xlats.get(out.substring(i, i + len));
	if (xlat != null) {
	  out.replace(i, i + len, xlat);
	}
      }
    }
    return(out.toString());
  }
  
  void sendText(String committed) {
    if (committed == null) {
      committed = "";
    }
    String full;
    int shownCursor;
    if ((cursor == 0) || (cursor == rawText.length())) {
      String rawCvt = convert(rawText.toString());
      full = committed + rawCvt;
      shownCursor = (cursor == 0 ? 0 : rawCvt.length());
    } else {
      String leftCvt = convert(rawText.substring(0, cursor));
      shownCursor = leftCvt.length();
      full = committed + leftCvt + convert(rawText.substring(cursor));
    }
    AttributedString as = new AttributedString(full);
    if (committed.length() > 0) {
      as.addAttribute(TextAttribute.INPUT_METHOD_HIGHLIGHT,
		      InputMethodHighlight.UNSELECTED_CONVERTED_TEXT_HIGHLIGHT,
		      0, committed.length());
    }
    if (committed.length() < full.length()) {
      InputMethodHighlight currentHighlight = null;
      int highlightStart = 0;
      for (int i = committed.length(); i < full.length(); ++i) {
	Character.UnicodeBlock ub = Character.UnicodeBlock.of(full.charAt(i));
	InputMethodHighlight newHighlight =
	  (((ub == Character.UnicodeBlock.HIRAGANA)
	    || (ub == Character.UnicodeBlock.KATAKANA))
	   ? InputMethodHighlight.SELECTED_CONVERTED_TEXT_HIGHLIGHT
	   : InputMethodHighlight.SELECTED_RAW_TEXT_HIGHLIGHT);
	if (newHighlight != currentHighlight) {
	  if (currentHighlight != null) {
	    as.addAttribute(TextAttribute.INPUT_METHOD_HIGHLIGHT,
			    currentHighlight, highlightStart, i);
	  }
	  currentHighlight = newHighlight;
	  highlightStart = i;
	}
      }
      as.addAttribute(TextAttribute.INPUT_METHOD_HIGHLIGHT,
		      currentHighlight, highlightStart, full.length());
    }
    inputMethodContext.dispatchInputMethodEvent(
      InputMethodEvent.INPUT_METHOD_TEXT_CHANGED,
      as.getIterator(),
      committed.length(),
      (shownCursor == 0
       ? TextHitInfo.leading(0)
       : TextHitInfo.trailing(shownCursor - 1)),
      null);
  }

  private static int initHashMap(HashMap map, String entries,
				 char smallTsu) {
    int maxLen = 0;
    String[] parts = entries.split("\\|");
    for (int i = 0; i < parts.length; i += 2) {
      String romaji = parts[i];
      String kana = parts[i + 1];
      if (romaji.length() > maxLen) {
	maxLen = romaji.length();
      }
      map.put(romaji, kana);
      switch(romaji.charAt(0)) {
      case 'k': case 'g': case 's': case 't':
      case 'm': case 'n': case 'r': case 'd':
      case 'b': case 'p': {
	String fullK = smallTsu + kana;
	map.put(romaji.charAt(0) + kana, fullK);
	map.put(romaji.charAt(0) + romaji, fullK);
      } break;
      case 'c': {
	String fullK = smallTsu + kana;
	map.put('t' + kana, fullK);
	map.put('t' + romaji, fullK);
      } break;
      default:
	break;
      }
    }
    return(maxLen);
  }
}
